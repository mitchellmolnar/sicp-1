// chapter=4 
const n1 = make_javascript_number(4);
const n2 = make_javascript_number(5);

add(n1, n2);
