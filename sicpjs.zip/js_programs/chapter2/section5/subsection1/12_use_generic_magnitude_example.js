// chapter=4 
const z = make_complex_from_real_imag(3, 4);

magnitude(z);

const z = make_complex_from_real_imag(3, 4);

magnitude(z);
