const alyssas_co_num = make_from_mag_ang(	  
                           3.0, 0.7);

imag_part(alyssas_co_num);
