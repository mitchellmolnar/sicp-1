// for_each to be given by student
