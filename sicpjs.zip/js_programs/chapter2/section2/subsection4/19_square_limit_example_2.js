show(square_limit(heart, 4));
