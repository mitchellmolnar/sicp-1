import { heart, show } from 'rune';

show(corner_split(heart, 4));

show(corner_split(heart, 4));
