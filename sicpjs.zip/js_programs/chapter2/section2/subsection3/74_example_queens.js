length(queens(8));
