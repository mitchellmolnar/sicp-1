is_prime_sum(list(8, 9));
