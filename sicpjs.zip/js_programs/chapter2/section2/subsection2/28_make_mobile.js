function make_mobile(left, right) {
    return list(left, right);
}
