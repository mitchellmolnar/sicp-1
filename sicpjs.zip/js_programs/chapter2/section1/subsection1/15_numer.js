function numer(x) {
    return head(x);
}
function denom(x) {
    return tail(x);
}
