print_interval(sub_interval(make_interval(0, 1), 
                            make_interval(0.6, 1.5)));
