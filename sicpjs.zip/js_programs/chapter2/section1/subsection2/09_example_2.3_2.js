const v = make_rect(make_point(1, 2), 2, 2);

perimeter_rect(v);
