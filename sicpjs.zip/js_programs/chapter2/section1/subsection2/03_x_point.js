// make_segment, start_segment, end_segment,
// make_point, x_point, and y_point to be
// written by student
