const my_leaf_1 = make_leaf("A", 8);
const my_leaf_2 = make_leaf("B", 3);

head(adjoin_set(my_leaf_1, adjoin_set(my_leaf_2, null)));
