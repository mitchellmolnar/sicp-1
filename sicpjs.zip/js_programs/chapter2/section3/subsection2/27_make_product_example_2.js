make_product(2, 3);
