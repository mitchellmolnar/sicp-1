function number_equal(exp, num) {
    return is_number(exp) && exp === num;
}

number_equal(3, 3);

// expected: true
